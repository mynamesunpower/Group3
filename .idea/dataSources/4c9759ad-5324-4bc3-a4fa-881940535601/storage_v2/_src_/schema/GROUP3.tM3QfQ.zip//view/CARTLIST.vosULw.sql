create view CARTLIST as
select b.TITLE title, b.isbn isbn, (b.price*c.quantity) price, c.quantity quantity, m.tel tel
from shopping_cart c INNER JOIN book b
      ON c.isbn = b.isbn
      INNER JOIN member m
      ON m.tel = C.tel
      where m.tel is not null
/

